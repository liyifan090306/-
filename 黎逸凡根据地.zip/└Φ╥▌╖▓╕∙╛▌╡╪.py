'''我的主页'''
import streamlit as st
from PIL import Image

page = st.sidebar.radio('我的首页', ['我的兴趣推荐', '我的图片处理工具', '我的智能词典', '我的留言区' , '写作推荐'])
"""
工作室名字：……
根据地用户：个人使用、只有几个人知道的秘密基地、分享后所有人可见……
根据地用途：工具分享、数据收集、兴趣推荐、经历分享、综合主站……
最喜欢的现有模块：兴趣推荐、图片处理工具、智慧词典、留言区
现有模块改进灵感：……
原创模块：……
原创模块一句话功能介绍：……
"""
def page_1():
    '''我的兴趣推荐'''
    with open('霞光.mp3','rb' ) as f:
        mymp3 = f.read( )
    st.audio(mymp3,format='audio/mp3',start_time=0) 
    st.image('slogan.png')
    st.write("以下是一些适合您的阅读推荐：")
    st.write("1. 《百年孤独》 - 加西亚·马尔克斯")
    st.write("2. 《平凡的世界》 - 路遥")
    st.write("3. 《人类简史》 - 尤瓦尔·赫拉利")
    st.write("推荐的音乐风格和歌手：")
    st.write("1. 流行音乐：周杰伦、Taylor Swift")
    st.write("2. 古典音乐：贝多芬、莫扎特")
    st.write("适合您的运动项目和相关资源：")
    st.write("1. 跑步：专业跑鞋推荐")
    st.write("2. 瑜伽：线上瑜伽课程")
    pass 

def page_2():
    '''我的图片处理工具'''
    st.write(":sunglasses:图片换色小程序:sunglasses:")
    uploaded_file = st.file_uploader("上传照片", type=['png', 'jpeg', 'jpg'])
    if uploaded_file:
        try:
            img = Image. open(uploaded_file)
            st. image(img)
            st. image(img_change(img, 0,1,2))
            tabl, tab2, tab3, tab4 = st. tabs(["原图", "改色1","改色2","改色3"])
            with tab1:
                st. image(img)
            with tab2:
                st. image(img_change(img, 2 ,1, 0))
            with tab3:
                st.write('### :red[这是一张102的rgb]')
                st. image(img_change(img, 1,0,2))
            with tab4:
                st.write('### :red[这是一张012的rgb]')
        except FileNotFoundError as fnfe:  
            st.error(f"文件未找到错误: {fnfe}")
        except IOError as ioe:
            st.error(f"输入输出错误: {ioe}")
        except Exception as e:  
            st.error(f"发生未知错误: {e.__class__.__name__}: {e}")

def page_3():
    '''我的智能词典'''
    pass

def page_4():
    '''我的留言区'''
    pass

def page_5():
    '''写作推荐'''
    pass

def img_change(img,rc,gc,bc) :
    '''图片处理'''
    width, height = img. size
    img_array = img. load()
    for x in range(width) :
        for y in range (height):
            r = img_array[x, y][rc]
            g = img_array[x, y][gc]
            b = img_array[x, y][bc]
            img_array[x,y] = (r, g, b)
    return img
    
            

if page == '我的兴趣推荐':
    page_1()
elif page == '我的图片处理工具':
    page_2()
elif page == '我的智能词典':
    page_3()
elif page == '我的留言区':
    page_4()
elif page == '写作推荐':
    page_5()
